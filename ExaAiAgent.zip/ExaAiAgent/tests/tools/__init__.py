"""Tests for strix.tools module."""

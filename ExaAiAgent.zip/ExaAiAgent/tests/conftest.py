"""Pytest configuration and shared fixtures for Strix tests."""

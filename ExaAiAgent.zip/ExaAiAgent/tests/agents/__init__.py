"""Tests for strix.agents module."""

"""Tests for strix.interface module."""

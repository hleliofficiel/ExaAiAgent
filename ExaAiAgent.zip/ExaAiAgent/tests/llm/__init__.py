"""Tests for strix.llm module."""

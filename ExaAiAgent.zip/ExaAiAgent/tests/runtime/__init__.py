"""Tests for strix.runtime module."""

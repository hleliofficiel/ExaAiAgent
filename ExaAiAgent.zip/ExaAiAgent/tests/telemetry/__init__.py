"""Tests for strix.telemetry module."""
